#include <thread>
#include <chrono>
#include <iostream>
#include <signal.h>

#include "../include/SensorManager.hpp"
#include "../include/DriveController.hpp"
#include "../include/Classes/Diagnostic.h"
#include "../include/Classes/CommandParser.h"
#include "../include/Classes/MainController.h"

bool g_KeepRunning = true;

void CSignalHandler(int signalNumber)
{
	DIAG_INFO("Caught signal %d, shutting down system", signalNumber);
	g_KeepRunning = false;
	CommandParser::shouldCancel = true;
}

int main(int argc, char** argv)
{
	auto sensorManager = SensorManager::getInstance();
	auto driveController = DriveController::getInstance();

	driveController->setTestMode(true);
	Diagnostics::setMaxLevel(DIAG_INFO);

	signal(SIGINT, CSignalHandler);

	int width = sensorManager->getSensorWidth();
	int height = sensorManager->getSensorHeight();
	int fps_counter = 0;
	double oldDepth = -1.f;
	int oldId = -1;
	bool found = false;

    ///Instantiate the MainController object
	MainController mainController;

	while (g_KeepRunning)
	{

		if (fps_counter == 50000) {
			std::cout << "Sensormanager-FPS: " << sensorManager->getFps() << "\r";
			fps_counter = 0;
		}

		if (!sensorManager->runOnce())
		{
			g_KeepRunning = false;
		}

		driveController->step();

		auto markers = sensorManager->getMarkerList();

		if (markers.size() == 0) {
			oldId = -1;
			oldDepth = -1;
			if (found) DIAG_INFO("Lost track of marker!");
			found = false;
		}
		else
		{
			found = true;
		}

		for (auto& marker : markers)
		{
			auto box = marker.m_Marker;
			auto boxCenterX = box.x() + (box.getWidth() / 2);
			auto boxCenterY = box.y() - (box.getHeight() / 2);
			auto depth = sensorManager->getDepth(boxCenterX, boxCenterY);
			auto id = marker.m_Id;
			// 0.06 == 0.1% bei Objektentfernung von 6
			if (found && (oldId != id) && ((depth - oldDepth > 0.06) || (oldDepth - depth > 0.06)) && depth != -1.f && depth > 0.f)
			{
				DIAG_INFO("Found Marker at depth %f with id %i", depth, id);
				oldId = id;
				oldDepth = depth;
			}
		}
		//driveController->updateController(0, 0);
		//driveController->step(); // -> use another thread

		//std::this_thread::sleep_until(now + std::chrono::milliseconds(5)); // rate-limit loop to 20 fps

        /** Take the user input from the console
         * This will check in every loop if the user has something to execute or not
         */
		mainController.takeUserInput();

		fps_counter++;
	}

	return 0;
}
