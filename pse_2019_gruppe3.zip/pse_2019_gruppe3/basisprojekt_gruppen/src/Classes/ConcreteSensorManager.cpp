///////////////////////////////////////////////////////////
//  ConcreteSensorManager.cpp
//  Implementation of the Interface ConcreteSensorManager
//  Created on:      28-Mai-2019 17:27:26
//  Original author: student
///////////////////////////////////////////////////////////

#include <string>

#include <ConcreteSensorManager.h>
#include <SensorManager.hpp>
#include <Diagnostic.h>

ConcreteSensorManager ConcreteSensorManager::instance_;
SensorManager ConcreteSensorManager::sensorManager_;

ConcreteSensorManager::ConcreteSensorManager(){
	DIAG_VERBOSE("ConcreteSensorManager has been created.");
	sensorManager_ = SensorManager::getInstance();
}

ConcreteSensorManager::~ConcreteSensorManager(){
	DIAG_VERBOSE("ConcreteSensorManager has been destroyed.");
}

void ConcreteSensorManager::setSensorManager(SensorManager sensorManager){
	sensorManager_ = sensorManager
	DIAG_DEBUG("ConcreteSensorManager::setSensorManager(). The sensormanager has been set.");
}

std::vector<MarkerInfo>& ConcreteSensorManager::get_marker_list(){
	DIAG_VERBOSE("oncreteSensorManager::get_marker_list(). MArker List has been queried.");
	return  SensorManager::getMarkerList();
}

double ConcreteSensorManager::getDepth(int x, int y){
	DIAG_VERBOSE("ConcreteSensorManager::getDepth(). Depth has been queried.");
	return SensorManager::getDepth();;
}

float ConcreteSensorManager::getFps(){
	DIAG_VERBOSE("ConcreteSensorManager::getFps(). FPS have been queried.");
	return SensorManager::getFps();
}

ConcreteSensorManager ConcreteSensorManager::getInstance(){
	if (!instance_)
	{
		DIAG_VERBOSE("ConcreteSensorManager::getInstance() an Instance of the Singleton has been created.")
		instance_ = &ConcreteSensorManager();
		instance_->sensorManager_ = SensorManager::getInstance();
	}
	return *instance_;
}

int ConcreteSensorManager::getSensorHeight(){
	DIAG_VERBOSE("ConcreteSensorManager::getSensorHeight(). The Sensors height has been queried.");
	return sensorManager_->getSensorHeight();
}

int ConcreteSensorManager::getSensorWidth(){
	DIAG_VERBOSE("ConcreteSensorManager::getSensorWidth(). The Sensors width has been queried.");
	return sensorManager_->getSensorWidth();
}

void ConcreteSensorManager::notifyObservers(){
	int count = 0;
	for each (auto obj in observerCollection_)
	{
		(*obj)->update();
		count++;
	}
	DIAG_DEBUG("ConcreteSensorManager::notifyObservers(). " + std:to_string(count) + " observers have been notified.");
}

int ConcreteSensorManager::registerObserver(Observer* observer){
	DIAG_VERBOSE("ConcreteSensorManager::registerObserver(). Another Observer has been registered.");
	observerCollection_.push_back(observer);
	return 0;
}

bool ConcreteSensorManager::runOnce(){
	bool returnVar = sensorManager_->runOnce();
	notifyObservers();
	if (returnVar)	{
		DIAG_VERBOSE("ConcreteSensorManager::runOnce(). Call was successful.");
	}
	else	{
		DIAG_ERROR("ConcreteSensorManager::runOnce(). CALL FAILED.");
	}
	return returnVar;
}

bool ConcreteSensorManager::unregisterObserver(Observer* observer){
	DIAG_VERBOSE("ConcreteSensorManager::unregisterObserver(). Observer has been unregistered.");
	observerCollection_.erase(std::remove(observerCollection_.begin(), observerCollection_.end(), observer), observerCollection_.end());
	return 0;
}