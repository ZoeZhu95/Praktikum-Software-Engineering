///////////////////////////////////////////////////////////
//  Command.cpp
//  Implementation of the Class Command
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#include <Command.h>

Command::Command(){

}



Command::~Command(){

}


int Command::execute(){

	return 0;
}