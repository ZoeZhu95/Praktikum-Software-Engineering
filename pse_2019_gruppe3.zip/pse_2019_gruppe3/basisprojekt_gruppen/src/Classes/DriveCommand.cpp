///////////////////////////////////////////////////////////
//  DriveCommand.cpp
//  Implementation of the Class DriveCommand
//  Get drive parameters from terminal to update the speed and steering
//  Created on:      28-Mai-2019 17:27:23
//  Original author: student
///////////////////////////////////////////////////////////

#include <thread>
#include <ctime>

#include <DriveCommand.h>
#include <ConcreteDriveController.h>
#include <CommandParser.h>


DriveCommand::DriveCommand(){

}



DriveCommand::~DriveCommand(){

}



/*execute drive command with 3 parameters*/
int DriveCommand::execute(unsigned int argTime, int argSpeed, int argSteering){
	time_t startTime = time(0);
	time_t driveDuration = argTime;
	bool exitLoop = false;
	myDriveController = ConcreteDriveController::getInstance();
	
	while (exitLoop != true || CommandParser::shouldCancel != true) {
		myDriveController->update(argSpeed, argSteering, MANUAL);
        myDriveController->step();
		if (time(0) - startTime > driveDuration) {
			exitLoop = true;
		}
	}
	return 0;
}

/*execute drive command with 2 parameters*/
int DriveCommand::execute(unsigned int argTime, int argSpeed){
    time_t startTime = time(0);
    time_t driveDuration = argTime;
    bool exitLoop = false;
    
    
    while (exitLoop != true || !CommandParser::shouldCancel) {
        myDriveController->update(argSpeed, 0, MANUAL);
		if (time(0) - startTime > driveDuration) {
			exitLoop = true;
		}
	}
    return 0;
}
