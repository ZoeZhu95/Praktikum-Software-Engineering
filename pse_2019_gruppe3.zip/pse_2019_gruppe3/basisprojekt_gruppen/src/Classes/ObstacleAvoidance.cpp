///////////////////////////////////////////////////////////
//  ObstacleAvoidance.cpp
//  Implementation of the Class ObstacleAvoidance
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#include <ConcreteSensorManager.h>
#include <Priority.h>
#include <Diagnostic.h>
#include <ObstacleAvoidance.h>
#include <DriveParameters.h>
#include <AvoidanceStrategy.h>
#include <ConcreteDriveController.h>

//This is an old method which is similar with emergency
DriveParameters ObstacleAvoidance::detectObstacle() {

	bool obstacleDetected = false;
	int pixelNummber = 50;
	int depthThreshold = 1;
	DriveParameters driveParameters;
	AvoidanceStrategy avoidanceStrategy;

	int count = 0;
	int sensorWidth = sensorManager_->getSensorWidth();
	int sensorHeight = sensorManager_->getSensorHeight();

	for (int i = 0; i < sensorWidth; i++) 
	{
		for (int j = 0; j < sensorHeight; j++) 
		{
			if (sensorManager_->getDepth(i, j) < depthThreshold) 
			{
				count++;
				if (count > pixelNummber) {
					obstacleDetected = true;
				}
			}
		}
	}

	if (obstacleDetected = true) {
		driveParameters = avoidanceStrategy.avoid();
		priority_ = AVOIDANCE;
		DIAG_INFO("Attention! Obstacke detected!");
		ConcreteDriveController* driveController;
		driveController->update(driveParameters.speed, driveParameters.steering, priority_);
	}

	return driveParameters;
}
void ObstacleAvoidance::update() {
	sensorManager_->getInstance();
	detectObstacle();
}