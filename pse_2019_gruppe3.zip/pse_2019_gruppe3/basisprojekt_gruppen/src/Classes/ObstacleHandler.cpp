///////////////////////////////////////////////////////////
//  ObstacleHandler.cpp
//  Implementation of the Class ObstacleHandler
//  Created on:      28-Mai-2019 17:27:25
//  Original author: student
///////////////////////////////////////////////////////////

#include <ObstacleHandler.h>


ObstacleHandler::ObstacleHandler(){

}



ObstacleHandler::~ObstacleHandler(){

}





int ObstacleHandler::invertEvasionPath(){

	return 0;
}


int ObstacleHandler::sampleDistancePoints(){

	return 0;
}