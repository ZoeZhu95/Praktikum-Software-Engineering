///////////////////////////////////////////////////////////
//  AvoidanceStop.cpp
//  Implementation of the Class AvoidanceStop
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#include <AvoidanceStop.h>
#include <DriveParameters.h>

AvoidanceStop::AvoidanceStop(){

}

AvoidanceStop::~AvoidanceStop(){

}

DriveParameters AvoidanceStop::avoid(){

	DriveParameters driveParameters;
	return driveParameters;

}