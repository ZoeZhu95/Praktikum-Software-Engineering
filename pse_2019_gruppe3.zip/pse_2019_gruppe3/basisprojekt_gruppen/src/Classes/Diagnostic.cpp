///////////////////////////////////////////////////////////
//  Diagnostic.cpp
//  Implementation of the Class Diagnostic
//  Created on:      28-Mai-2019 17:27:23
//  Original author: student
///////////////////////////////////////////////////////////

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <time.h>
#include <stdio.h>

#include <Diagnostic.h>

DiagnosticLevel Diagnostic::diagnosticsLevel;

Diagnostic::~Diagnostic() {

}


Diagnostic::Diagnostic() {
	
}


void Diagnostic::log(DiagnosticLevel Level, const char* File, int Line, const char* const msg) {
	static bool consoleOnly = false;
	static bool firstRun = true;
	if (Level <= diagnosticsLevel) {
		time_t now = time(0);
		struct tm tstruct;
		char timeBuffer[80];
		tstruct = *localtime(&now);
		strftime(timeBuffer, 80, "%H:%M", &tstruct);

		if (!consoleOnly) {
			std::ofstream outputFile;
			std::ios_base::openmode openMode = std::ios::app;
			if (firstRun) {
				#ifdef OUTPUT_FLUSH
					openMode = std::ios::trunc;
				#endif
			}
			outputFile.open(DIAG_OUTPUT, (const std::ios_base::openmode) openMode);
			if (!outputFile.is_open()) {
				std::cout << "Error: Could not open log file!\n"
					"From now on, the debug messages will only be outputed to the console\n";
				consoleOnly = true;
			}
			else {
				outputFile << "[" << timeBuffer << "]\tLine " << Line << " of " << __FILE__ << " :\n" << "\t\t" << output << std::endl;
				outputFile.close();
			}
		}
		std::cout << "[" << timeBuffer << "]\tLine " << Line << " of " << __FILE__ << " :\n" << "\t\t" << output << std::endl;
		firstRun = false;
	}
}


void Diagnostic::setMaxLevel(DiagnosticLevel Level) {
	diagnosticsLevel = Level;
}
