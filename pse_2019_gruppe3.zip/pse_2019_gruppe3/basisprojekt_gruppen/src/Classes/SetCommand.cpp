///////////////////////////////////////////////////////////
//  SetCommand.cpp
//  Implementation of the Class SetCommand
//  Created on:      28-Mai-2019 17:27:27
//  Original author: student
///////////////////////////////////////////////////////////

#include <SetCommand.h>
#include <CommandParser.h>
#include <MainController.h>
#include <Diagnostic.h>

SetCommand::SetCommand(){

}



SetCommand::~SetCommand(){

}




/**	setting from Terminal
 *	@brief 3 types: set log_level, set max time interval between 2 commands, set distance to track marker
 *	using MainController and Diagnostics 
 */
int SetCommand::execute(SetType art, unsigned int value){
	if (art == Logging)
	{
		std::string levelNames[5] = {"ERROR", "WARNING","INFO","DEBUG","VERBOSE"}
		DIAG_MAX_LEVEL((DiagnosticLevel) value);	/// call diagnostics class
		DIAG_INFO("Diagnostics level is set to: DIAG_" << levelNames[value]);											
	}
	else if (art == RunTime)
	{
		MainController::setControlInterval(value);
		DIAG_INFO("RunTime is set to:" << value);
	}
	else if (art == Distance2Marker)
	{
		MainController::setFollowDistance(value);			/// "disdance" expected double type, given int type in fact
		DIAG_INFO("Distance is set to:" << value);
	}
	return 0;
}