///////////////////////////////////////////////////////////
//  Observer.cpp
//  Implementation of the Class Observer
//  Created on:      28-Mai-2019 17:27:25
//  Original author: student
///////////////////////////////////////////////////////////

#include <Observer.h>


Observer::Observer(){

}

Observer::~Observer(){

}

void Observer::update(){

}