///////////////////////////////////////////////////////////
//  MarkerDetector.cpp
//  Implementation of the Class MarkerDetector
//  Created on:      28-Mai-2019 17:27:24
//  Original author: student
///////////////////////////////////////////////////////////

#include <vector>
#include <iostream>

#include <MarkerInfo.hpp>
#include <Diagnostic.h>
#include <MarkerDetector.h>
#include <ConcreteSensorManager.h>
#include <TrackingHandler.h>

MarkerDetector::MarkerDetector() {
	markerlist_ = sensorManager_->getMarkerList();
	seesMarker = seesMarker_f();
	markerCenter = getMarkerCenter();
}

void MarkerDetector::setMarkerID(int followID) {
	followID_ = NULL;
	for (auto _id : possibleIDs)
	{
		if (_id == followID)
		{
			followID_ = followID;
			DIAG_INFO("find the valid followID");
		}
	}
	if (followID_ == NULL)
	{
		DIAG_WARNING("FollowID is possibily incorrect!");
	}
}

Point MarkerDetector::getMarkerCenter() {
	Point markerCenter1;
	MarkerInfo marker;

	for (auto marker : markerlist_)
	{
		if (marker.m_Id == followID_) break;
	}
	markerCenter1.xValue = marker.m_Marker.x() + marker.m_Marker.getWidth() / 2;
	markerCenter1.yValue = marker.m_Marker.y() + marker.m_Marker.getHeight() / 2;
	markerCenter1.depth = sensorManager_->getDepth(markerCenter1.xValue, markerCenter1.yValue);
	
	DIAG_INFO("get the current marker's center");

	return markerCenter1;
}

bool MarkerDetector::seesMarker_f() {
	seesMarker = false;
	for (auto marker : markerlist_)
	{
		if (marker.m_Id == followID_)
		{
			seesMarker = true;
			DIAG_INFO("See the valid Marker.");
			getMarkerCenter();
			TrackingHandler::decideDriveVector();
		}
	}
	if(seesMarker = false)
	{
		DIAG_INFO("Don't find the valid Marker.");
		trackingHandler_->searchMarker();
	}
	return seesMarker;
}

void MarkerDetector::update() {
	sensorManager_->getInstance();
	MarkerDetector();
}
