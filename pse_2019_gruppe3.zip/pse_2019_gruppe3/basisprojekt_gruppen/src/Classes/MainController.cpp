///////////////////////////////////////////////////////////
//  MainController.cpp
//  Implementation of the Class MainController
//  Created on:      28-Mai-2019 17:27:24
//  Original author: student
///////////////////////////////////////////////////////////

#include <thread>
#include <chrono>
#include <string>

#include <MainController.h>
#include <Diagnostic.h>

MainController::MainController(){
	// ~ 10s as an initial maximum time between calls
	lastCommandInterval_ = 10000; 
	commandParser = BefehlsParser();
	concreteSensorManager = ConcreteSensorManager::getInstance();
	concreteDriveController_ = ConcreteDriveController::getInstance();
	DIAG_VERBOSE("MainController has been constructed. The default permissible Interval between commands is " + std::to_string(lastCommandInterval_));
}

MainController::~MainController(){
	DIAG_VERBOSE("MainController has been destructed.");
}

MainController::getFollowDistance(){
	DIAG_VERBOSE("MainController::getFollowDistance(). Followdistance has been queried.");
	return followDistance_;
}

void MainController::callFrequently(bool active){
	DIAG_VERBOSE("MainController::callFrequently(). Frequent calling has been initiated.");
	callFrequentlyActive_ = active;
	asyncCall_ = std::thread(asyncCallFrequently);
}

void MainController::asyncCallFrequently(){
	auto runOnceTime = std::chrono::steady_clock::now();
	auto stepTime = std::chrono::steady_clock::now();

	while (callFrequentlyActive_)
	{
		concreteDriveController_->step();
		stepTime += std::chrono::milliseconds(STEP_INTERVAL_);
		if (runOnceTime < stepTime)
		{
			concreteSensorManager->runOnce();
			runOnceTime += std::chrono::milliseconds(RUN_ONCE_INTERVAL_);
		}
		checkStopTime();
		std::this_thread::sleep_until(stepTime);
	}
}

void MainController::updateCommandTimer(){
	DIAG_DEBUG("MainController::updateCommandTimer(). Command TImer has been reset.");
	callFrequentlyActive_ = true;
	lastCommandTimestamp_ = std::chrono::steady_clock::now();
}

void MainController::checkStopTime(){
	if (lastCommandTimestamp_ + lastCommandInterval_ < std::chrono::steady_clock::now())
	{
		callFrequentlyActive_ = false;
		concreteDriveController_.flush(EMERGENCY);
		DIAG_WARNING("MainController::checkStopTime(). Too much time has passed since the last command. \nDriveController has been flushed. CallFrequently has been suspended until the next Command will be given.");
	}
}

int MainController::setControlInterval(int input){
	lastCommandInterval_ = input;
	DIAG_VERBOSE("MainController::setControlInterval(). Command Interval has been set to: " + std:to_string(input));
	return 0;
}

int MainController::setFollowDistance(double distance){
	followDistance_ = distance;
	DIAG_VERBOSE("MainController::setFollowDistance(). Follow Distance has been set to: " + std:to_string(distance));
	return 0;
}

int MainController::takeUserInput(){
	std::string commandToParse;
	while (true) 
	{
		std::getline(std::cin, commandToParse);
		int returnValue = commandParser->parse(commandToParse);
		if (returnValue) {
			DIAG_ERROR("Parsing of last command failed!");
			break;
		}
	}
	return returnValue;
}