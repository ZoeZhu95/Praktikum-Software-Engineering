///////////////////////////////////////////////////////////
//  Point.cpp
//  Implementation of the Class Point
//  Created on:      28-Mai-2019 17:27:25
//  Original author: student
///////////////////////////////////////////////////////////

#include <Point.h>

Point::Point(){
	xValue = 0;
	yValue = 0;
	depth = 0;
}

Point::~Point(){

}
