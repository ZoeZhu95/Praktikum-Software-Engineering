///////////////////////////////////////////////////////////
//  ConcreteDriveController.cpp
//  Implementation of the Class ConcreteDriveController
//  Created on:      28-Mai-2019 17:27:23
//  Original author: student
///////////////////////////////////////////////////////////

#include <string>

#include <ConcreteDriveController.h>
#include <DriveController.hpp>
#include <Diagnostic.h>

DriveController ConcreteDriveController::driveController_;
ConcreteDriveController ConcreteDriveController::instance_;

ConcreteDriveController::ConcreteDriveController(){
	DIAG_VERBOSE("ConcreteDriveController has been constructed");
	driveController_ = DriveController::getInstance();
}

ConcreteDriveController::~ConcreteDriveController(){
	DIAG_VERBOSE("ConcreteDriveController has been destroyed");
}

int ConcreteDriveController::getSpeed(){
	if (currentInstruction_ != NULL)
	{
		DIAG_DEBUG("ConcreteDriveController::getSpeed(). The Speed has been queried. Speed is : " + sts::to_string(currentInstruction_.speed));
		return currentInstruction_.speed;
	}
	else
	{
		DIAG_WARNING("ConcreteDriveController::getSpeed(). Speed has been queried but has not been set.");
		return 0;
	}
}

DrivingMode ConcreteDriveController::getMode(){
	DIAG_VERBOSE("ConcreteDriveController::getMode(). Mode has been queried.");
	return  currentMode_;
}

ConcreteDriveController ConcreteDriveController::getInstance(){
	if (!instance_)
	{
		instance_ = &ConcreteDriveController();
		instance_->driveController_ = DriveController::getInstance();
		DIAG_VERBOSE("ConcreteDriveController::getInstance() an Instance of the Singleton has been created.");
	}
	return instance_;
}

void ConcreteDriveController::setDriveController(DriveController* driveController){
	driveController_ = driveController;
	DIAG_DEBUG("ConcreteDriveController::setDriveController(). A driveController has been set.");
}

bool ConcreteDriveController::getTestMode(){
	// returns true only when a testing mode is enabled
	if (currentMode_ == TEST_AUTO || currentMode_ == TEST_MANUAL)
	{
		DIAG_VERBOSE("ConcreteDriveController::getTestMode(). We are in TEST mode.");
		return true;
	}
	DIAG_VERBOSE("ConcreteDriveController::getTestMode(). We are NOT in TEST mode.");
	return false;
}

int ConcreteDriveController::setMode(int mode){
	currentMode_ = mode;
	DIAG_VERBOSE("ConcreteDriveController::setMode(). The DriveMode has been set to." + std::to_string(mode) + "\n\tsee DrivingMode for more Information.");
	return 0;
}

void ConcreteDriveController::setTestMode(bool enable){
	if (currentMode_ == AUTO && enable)
	{
		currentMode_ = TEST_AUTO;
	}
	if (currentMode_ == MANUAL && enable)
	{
		currentMode_ == TEST_MANUAL;
	}
	if (currentMode_ == TEST_AUTO && !enable)
	{
		currentMode_ = AUTO;
	}
	if (currentMode_ == TEST_MANUAL && !enable)
	{
		currentMode_ = MANUAL;
	}
	DIAG_VERBOSE("ConcreteDriveController::setTestMode(). Test mode has been set to: " + std::to_string(enable));
}

void ConcreteDriveController::step(){
	int mySpeed = currentInstruction_.speed;
	int mySteering = currentInstruction_.steering;
	if (getTestMode)	// Im Testmodus direktes update, sonst Controllerupdate
	{
		updateDirect(mySpeed, mySteering);
	}
	else
	{
		updateController(mySpeed, mySteering);
	}
	driveController_->step();
}

int ConcreteDriveController::flush(Priority priority){
	// failed to flush because it was not important enough
	if (priority < currentPriority_)	
	{
		DIAG_WARNING("ConcreteDriveController::flush(). Flush failed due to low priority.");
		return 1;
	}
	else
	{
		currentPriority_ = priority;
	}
	if (priority == DISASTER)
	{
		std::queue<DriveParameters>().swap(emergencyQueue_);
		std::queue<DriveParameters>().swap(avoidanceQueue_);
		std::queue<DriveParameters>().swap(manualQueue_);
		std::queue<DriveParameters>().swap(trackingQueue_);
		DIAG_VERBOSE("ConcreteDriveController::flush(). DISASTER flush completed.");
	}
	if (priority == EMERGENCY)
	{
		std::queue<DriveParameters>().swap(emergencyQueue_);
		std::queue<DriveParameters>().swap(avoidanceQueue_);
		std::queue<DriveParameters>().swap(manualQueue_);
		std::queue<DriveParameters>().swap(trackingQueue_);
		DIAG_VERBOSE("ConcreteDriveController::flush(). EMERGENCY flush completed.");
	}
	if (priority == AVOIDANCE)
	{
		std::queue<DriveParameters>().swap(avoidanceQueue_);
		std::queue<DriveParameters>().swap(manualQueue_);
		std::queue<DriveParameters>().swap(trackingQueue_);
		DIAG_VERBOSE("ConcreteDriveController::flush(). AVOIDANCE flush completed.");
	}
	if (priority == MANUAL)
	{
		std::queue<DriveParameters>().swap(manualQueue_);
		std::queue<DriveParameters>().swap(trackingQueue_);
		DIAG_VERBOSE("ConcreteDriveController::flush(). MANUAL flush completed.");
	}
	if (priority == TRACKING)
	{
		std::queue<DriveParameters>().swap(trackingQueue_);
		DIAG_VERBOSE("ConcreteDriveController::flush(). TRACKING flush completed.");
	}
	setInstruction();
	return 0;
}

/*
 * buffer inputs and decide which input to process based on priority
 */
bool ConcreteDriveController::update(int speed, int steering, Priority priority){
	// disregard instructions of lower priority than the current instructions priority
	if (priority < currentPriority_) 
	{
		DIAG_WARNING("ConcreteDriveController::update(). Failed due to low priority.");
		return false;
	}
	DriveParameters insertInstruction;
	insertInstruction.speed = speed;
	insertInstruction.steering = steering;
	if (priority == EMERGENCY)
	{
		emergencyQueue_.push(insertInstruction);
	}
	if (priority == AVOIDANCE)
	{
		avoidanceQueue_.push(insertInstruction);
	}
	if (priority == MANUAL)
	{
		manualQueue_.push(insertInstruction);
	}
	if (priority == TRACKING && (currentMode_ == AUTO ||currentMode_ == TEST_AUTO))
	{
		trackingQueue_.push(insertInstruction);
	}
	setInstruction();
	DIAG_VERBOSE("ConcreteDriveController::update(). Update received.");
	return true;
}

/*	
* Function for setting the Instruction to be executed when calling step()
*/
void ConcreteDriveController::setInstruction(){
	// extract highest priority instructon if there is a new one
	DriveParameters executeInstruction;
	if (!emergencyQueue_.empty())
	{
		executeInstruction = emergencyQueue_.pop();
		currentPriority_ = EMERGENCY;
	}
	else if (!avoidanceQueue_.empty())
	{
		executeInstruction = avoidanceQueue_.pop();
		currentPriority_ = AVOIDANCE;
	}
	else if (!manualQueue_.empty())
	{
		executeInstruction = manualQueue_.pop();
		currentPriority_ = MANUAL;
	}
	else if (!trackingQueue_.empty())
	{
		executeInstruction = trackingQueue_.pop();
		currentPriority_ = TRACKING;
	}
	else	// if there are no Instructions do nothing, 0 steering and 0 speed.
	{
		DIAG_WARNING("ConcreteDriveController has no Instruction to execute, setting instruction to Speed: 0, steering: 0.");
		DriveParameters doNothing;
		doNothing.speed = 0;
		doNothing.steering = 0;
		executeInstruction = doNothing;
	}
	currentInstruction_ = executeInstruction;
	DIAG_VERBOSE("ConcreteDriveController reset the current Instruction.");
}

bool ConcreteDriveController::updateDirectMotor(int speedLeft, int speedRight){
	bool retVal = driveController_->updateDirectMotor(speedLeft, speedRight);
	if (retVal)	{
		DIAG_VERBOSE("ConcreteDriveController used its driveController to execute updateDirectMotor.");
	}
	else	{
		DIAG_ERROR("ConcreteDriveController failed use its driveCOntroller to execute updateDirectMotor.");
	}
	return retVal;
}

bool ConcreteDriveController::updateController(int speed, int steering){
	bool retVal = driveController_->updateController(speed, steering);
	if (retVal) {
		DIAG_VERBOSE("ConcreteDriveController used its driveController to execute updateController.");
	}
	else {
		DIAG_ERROR("ConcreteDriveController failed use its driveCOntroller to execute updateController.");
	}
	return retVal;
}

bool ConcreteDriveController::updateDirect(int speed, int steering){
	bool retVal = driveController_->updateDirect(speed, steering);
	if (retVal) {
		DIAG_VERBOSE("ConcreteDriveController used its driveController to execute updateDirect.");
	}
	else {
		DIAG_ERROR("ConcreteDriveController failed use its driveCOntroller to execute updateDirect.");
	}
	return retVal;
}