///////////////////////////////////////////////////////////
//  AvoidanceStrategy.cpp
//  Implementation of the Class AvoidanceStrategy
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#include <AvoidanceStrategy.h>
#include <DriveParameters.h>

AvoidanceStrategy::AvoidanceStrategy(){

}

AvoidanceStrategy::~AvoidanceStrategy(){

}

DriveParameters AvoidanceStrategy::avoid(){

	DriveParameters driveParameters;
	return driveParameters;

}