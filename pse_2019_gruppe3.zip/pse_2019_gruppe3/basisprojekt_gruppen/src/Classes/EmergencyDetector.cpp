///////////////////////////////////////////////////////////
//  EmergencyDetector.cpp
//  Implementation of the Class EmergencyDetector
//  Created on:      28-Mai-2019 17:27:24
//  Original author: student
///////////////////////////////////////////////////////////

#include <stdlib.h>
#include <time.h> 
#include <math.h>

#include <EmergencyDetector.h>
#include <Diagnostic.h>
#include <DriveParameters.h>
#include <ConcreteDriveController.h>

void EmergencyDetector::setDangerDepth(int dangerDepth) {
	//all depth values with unit[m]
	dangerDepth_ = dangerDepth; 
}

/**
* image pixel 1280 x 720
* after sampling, we use only 10x4x5=200 pixel data
*/
DriveParameters EmergencyDetector::detectEmergency() {
	
	sensorManager_->getInstance();

	int x[5];
	int y[5];
	double referDepth[216] = { 0 };
	double noiseThreshold = 0.1;
	bool emergencyDetect = false;
	DriveParameters driveParameters;

	//generate referDepth, and store it in array referDepth
	for (int i = 1; i < 216; i++)
	{
		/**
		* the following referDepth function is based on real messed data
		* based on "intel realsense depth camera D435"
		*/
		referDepth[i] = 0.0001216 * pow(i, 3) - 0.0229 * pow(i, 2) + 1.844 * i + 54.54;
	}

	srand((unsigned)time(NULL));

	//space depth information comparation
	for (int j = 0; j < 7; j++)
	{
		for (int k = 1; k < 5; k++) 
		{
			for (int i = 0; i < 5; i++)  //generate 5 random points in rectangle
			{
				//randX in range [0, 213]
				x[i] = 213 * k + rand() % 214; 
				//randY in range [0, 72]
				y[i] = 72 * j + rand() % 73; 
				if (sensorManager_->getDepth(x[i], y[i]) < dangerDepth_)
				{
					emergencyDetect = true;
				}
			}
		}
	}

	//ground depth information comparation
	for (int j = 7; j < 10; j++)
	{
		for (int k = 1; k < 5; k++)
		{
			for (int i = 0; i < 5; i++)
			{
				x[i] = 213 * k + rand() % 214; 
				y[i] = 72 * j + rand() % 73; 

				//if detected depth is not a ground depth 
				if ((sensorManager_->getDepth(x[i], y[i]) < referDepth[y[i] - 504]) && ((sensorManager_->getDepth(x[i], y[i]) - referDepth[y[i] - 504]) > noiseThreshold))
				{
					//and if it's smaller than dangerDepth, emergency is detected
					if (sensorManager_->getDepth(x[i], y[i]) < dangerDepth_)
					{
						emergencyDetect = true;
					}
				}
			}
		}
	}

	//if an emergency is detected, TivSeg should stop immediately
	if (emergencyDetect = true)
	{
		driveParameters.steering = 0;
		driveParameters.speed = 0;
		priority_ = EMERGENCY;
		DIAG_ERROR("Emergency! Here can not pass!");
		//sending command to driveController
		ConcreteDriveController* driveController;
		driveController->update(driveParameters.speed, driveParameters.steering, priority_);	
	}

	return driveParameters;
}

void EmergencyDetector::update() {
	detectEmergency();
}