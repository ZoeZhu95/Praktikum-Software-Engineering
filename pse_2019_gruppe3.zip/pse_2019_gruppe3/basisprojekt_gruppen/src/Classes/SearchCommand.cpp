///////////////////////////////////////////////////////////
//  SearchCommand.cpp
//  Implementation of the Class SearchCommand
//  Created on:      28-Mai-2019 17:27:26
//  Original author: student
///////////////////////////////////////////////////////////

#include <SearchCommand.h>
#include <TrackingHandler.h>

SearchCommand::SearchCommand(){

}



SearchCommand::~SearchCommand(){

}



int SearchCommand::execute(){
	TrackingHandler track;
	while(!Commandparser::shouldCancel || !done){
		bool done; 		// if done=1, marker is found
		done = track.searchMarker();
	}	
	return 0;
}


int SearchCommand::search(){

	return 0;
}