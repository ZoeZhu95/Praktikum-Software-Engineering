///////////////////////////////////////////////////////////
//  TrackingHandler.cpp
//  Implementation of the Class TrackingHandler
//  Created on:      28-Mai-2019 17:27:27
//  Original author: student
///////////////////////////////////////////////////////////


#include <TrackingHandler.h>
#include <ConcreteSensorManager.h>
#include <ConcreteDriveController.h>
#include <Priority.h>
#include <Diagnostic.h>
#include <Point.h>

TrackingHandler::TrackingHandler(){
    DIAG_VERBOSE("TrackingHandler has been constructed.");
}


TrackingHandler::~TrackingHandler(){
    DIAG_VERBOSE("TrackingHandler has been destructed.");
}


bool TrackingHandler::searchMarker(){
	ConcreteDriveController *myDriveController_;
	myDriveController_ = ConcreteDriveController::getInstance();
	MarkerDetector markerDetector_;
	bool flag = markerDetector_.seesMarker_f();
	while (!markerDetector_.seesMarker_f())
	{
		//slow turn speed so we don't miss the marker when the image is updated while turning
		myDriveController_->update(1, 25, TRACKING);	
	}
	return flag;
}


int TrackingHandler::decideDriveVector(){
	// get actual depth from markerDetector
	MarkerDetector markerDetector_;
	Point markerCenter_ = markerDetector_.getMarkerCenter();
	double actualDepth = markerCenter_.depth;
	// get the depth that should be kept from MainController
	MainController myMainController_;
	double myDepth = myMainController_.getFollowDistance();
	// get lastspeed from ConcreteDriveController
	ConcreteDriveController* myDriveController_;
	myDriveController_ = ConcreteDriveController::getInstance();
	int lastSpeed_ = myDriveController_ -> getSpeed();
	//get the new speed according to the lastspeed
	//assume a multiplier factor a
	int a;
	if (actualDepth < myDepth)
	{
		a = 50;
	}	
	else
	{
		a = 20;
	}
	int speed_ = a * (actualDepth - myDepth) /myDepth + lastSpeed_;

	if (speed_ > 0 && speed_ < 100) 
	{
		DIAG_VERBOSE("the Tivseg should be driven at the speed" + speed_);
	}
	else 
	{
		if (speed_ < 0 || actualDepth < 5) 
		{
			speed_ = 0;
			DIAG_VERBOSE("the Tivseg should be stopped");
		}
		else if (speed_ > 0)
		{
			speed_ = 100;
			DIAG_VERBOSE("the Tivseg should be driven at a full jump");
		}
	}
		
	//get the projection of the markercenter on the sensormanager
	int xMarker = markerCenter_.xValue;
	int yMarker = markerCenter_.yValue;
	//Assume left and top is the original of the coordinate
	//get the center of sensormanager
	ConcreteSensorManager* mySensorManager_;
	mySensorManager_ = ConcreteSensorManager::getInstance();
	int imageWidth = mySensorManager_->getSensorWidth();
	int imageHeight = mySensorManager_->getSensorHeight();
	int xCenter = imageWidth/2;
	int yCenter = imageHeight/2;
	//compare the projection of markercenter with the center of sensormanager
	//assume factor value = 50
	int b = 50;
	int steering_ = b * (xMarker - xCenter) / xCenter;
	if (steering_ < 100 && steering_ > -100) 
	{
		if (xMarker < xCenter)
		{
			DIAG_VERBOSE ("the Tivseg should turn left with the steering" + steering_);
		}
		else if (xMarker > xCenter)
		{
			DIAG_VERBOSE ("the Tivseg should turn right with the steering" + steering_);
		}
		else 
		{
			DIAG_VERBOSE ("the Tivseg should go straight" );
		}
	}
	else 
	{
		if (xMarker < xCenter)
		{
			steering_ = -100;
			DIAG_VERBOSE("the Tivseg should turn left with full steering");
		}
		else 
		{
			steering_ = 100;
			DIAG_VERBOSE("the Tivseg should turn left with full steering");
		}
	}	
	
	ConcreteDriveController* myDriveController_;
	myDriveController_ = ConcreteDriveController::getInstance();
	myDriveController_ -> update(speed_, steering_, TRACKING);

	return 0;
}


