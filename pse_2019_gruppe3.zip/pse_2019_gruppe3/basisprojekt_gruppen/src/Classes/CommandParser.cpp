///////////////////////////////////////////////////////////
//  CommandParser.cpp
//  Implementation of the Class CommandParser
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <csignal>
#include <algorithm>

#include <CommandParser.h>
#include <DriveCommand.h>
#include <ModeCommand.h>
#include <SetCommand.h>
#include <SearchCommand.h>
#include <ScriptCommand.h>
#include <Diagnostic.h>
#include <SetType.h>

CommandParser::CommandParser(){
    
}



CommandParser::~CommandParser(){
    
}



int str2int(std::string inputStr){
    return std::stoi(inputStr);
}


int CommandParser::parseCommand(std::string cmdToExecute){
    std::transform(cmdToExecute.begin(), cmdToExecute.end(), cmdToExecute.begin(), ::tolower);
    std::size_t firstSpace = cmdToExecute.find(' ');
    std::string myCommand = "";
    if(firstSpace != std::string::npos)
	{
        myCommand = cmdToExecute.substr(0, firstSpace);
        std::size_t secondSpace = cmdToExecute.find(' ', firstSpace+1);
        
		///command is "set"
		if(myCommand.compare("set") == 0)
        {
			std::string setType="";
            if(secondSpace != std::string::npos)
			{
                setType = cmdToExecute.substr(firstSpace + 1, 2);
                std::string logArg = cmdToExecute.substr(secondSpace+1);
                int setArg=str2int(logArg);							
				if (setArg != std::invalid_argument) 
                {
					DIAG_INFO("parse " << myCommand << " " << setType << " " << setArg);
					if (setType.compare("-l") == 0)
					{
						if (setArg < 0 || setArg > 4)
						{
                            DIAG_ERROR("failed to parse set-l: argument is out of range");
						}
						else
						{
							SetCommand setL;
							setL.execute(LOGGING, setArg);
						}
					}
					else if (setType.compare("-t") == 0)
					{
						SetCommand setT;
						setT.execute(RUN_TIME, setArg);
					}
					else if (setType.compare("-d") == 0)
					{
						SetCommand setD;
						setD.execute(DISTANCE_TO_MARKER, setArg);
					}
					else
					{
						DIAG_ERROR("failed to parse set-t: invalid SetCommand");
					}
				} 
				else
				{
					DIAG_ERROR("failed to parse set: expected pure number as argument");
				}
            }
			else
			{
                DIAG_ERROR("failed to parse set: expected space after set");
            }
        } 
		
		///command is "drive"
		else if(myCommand.compare("drive") == 0)
		{
            int driveTime;
            int driveSpeed;
            int driveSteering = 0; // default steering = 0
            std::size_t thirdSpace = cmdToExecute.find(' ',secondSpace + 1);
            /// drive command with 3 parameters
            if(secondSpace != std::string::npos && thirdSpace != std::string::npos)
			{
                std::string time = cmdToExecute.substr(firstSpace + 1, secondSpace-firstSpace - 1);
                std::string speed = cmdToExecute.substr(secondSpace + 1, thirdSpace-secondSpace - 1);
                std::string steering = cmdToExecute.substr(thirdSpace + 1);
                driveTime = str2int(time);
                driveSpeed = str2int(speed);
                driveSteering = str2int(steering);
                if (driveTime == std::invalid_argument || driveSpeed == std::invalid_argument || driveSteering == std::invalid_argument)
                {
                    DIAG_ERROR("failed to parse drive: expected pure number as argument");
                } 
                else
                {
                    if(driveTime >= 0 && driveTime <= max_drive_time) 
                    {
                        if(driveSpeed >= -100 && driveSpeed <= 100) 
                        {
                            if(driveSteering >= -100 && driveSteering <= 100)
                            {
                                DIAG_INFO("drive TivSeg for "<<driveTime<<" sec with "<<driveSpeed<<" km/h in "<<driveSteering<<" grad");
                                DriveCommand drive;							
                                drive.execute(driveTime, driveSpeed, driveSteering);						
                            } 
                            else
                            {
                                DIAG_ERROR("failed to parse drive: out of pre-defined steering range [-100,100]");
                            }
                            
                        } 
                        else 
                        {
                            DIAG_ERROR("failed to parse drive: out of pre-defined speed range [-100,100]");
                        }            
                    } 
                    else 
                    {
                        DIAG_ERROR("failed to parse drive: out of pre-defined time range [0,"<<max_drive_time<<"]");
                    } 
                }                                         
            } 
            /// drive command with 2 parameters			
			else if (secondSpace != std::string::npos && thirdSpace ==std::string::npos) 
			{
                std::string time = cmdToExecute.substr(firstSpace + 1, secondSpace - firstSpace - 1);
                std::string speed = cmdToExecute.substr(secondSpace + 1);
                driveTime = str2int(time);
                driveSpeed = str2int(speed);
                if (driveTime == std::invalid_argument || driveSpeed == std::invalid_argument)
                {
                    DIAG_ERROR("failed to parse drive: expected pure number as argument");
                } 
                else
                {
                    if(t>=0 && t<=max_drive_time) 
                    {
                        if(v>= -100 && v<= 100) 
                        {
                            DIAG_INFO("drive TivSeg for "<<driveTime<<" sec with "<<driveSpeed<<" km/h in 0 grad");
                            DriveCommand drive;
                            drive.execute(driveTime, driveSpeed, 0);
                        } 
                        else 
                        {
                            DIAG_ERROR("failed to parse drive: out of pre-defined speed range [-100,100]");
                        }
                    }
                    else 
                    {
                        DIAG_ERROR("failed to parse drive: out of pre-defined time range [0,"<<max_drive_time<<"]");
                    }
                }
            } 
			else 
			{
                DIAG_ERROR("failed to parse drive: expected spaces between 2 arguments");
            }
        } 

		/// command is script
		else if(myCommand.compare("script") == 0)
		{
            std::string filePath = cmdToExecute.substr(firstSpace + 1);
            setInputStream(filePath);
        } 
        /// command is mode
		else if(myCommand.compare("mode") == 0)
		{
            if(secondSpace == std::string::npos)
			{
                std::string modeNr = cmdToExecute.substr(firstSpace + 1);
                int modeArg=str2int(modeNr);
                if (modeArg != std::invalid_argument) 
                {
                    DIAG_ERROR("failed to parse drive: expected pure number as argument");
                }
                else
                {
                    if(modeArg==1 || modeArg==2)
                    {
                        DIAG_INFO("Mode is set to "<<modeArg);
                        ModeCommand mode;
                        mode.execute(modeArg);
                    } 
                    else 
                    {
                        DIAG_ERROR("failed to parse mode:expected '1' or '2' as argument");
                    }
                }
            } 
			else 
			{
                DIAG_ERROR("failed to parse mode: extra spaces detected");
            }
        }
		else 
		{
            DIAG_ERROR("failed to parse command: invalid command format");
        }    
    }	
	///command is search
	else if(cmdToExecute.compare("search") == 0)
	{
        DIAG_INFO("parse command search");
        SearchCommand search;
        search.execute();
    } 
	/// no space is detected, invalid command
	else 
	{
        DIAG_ERROR("failed to parse command: invalid command format");
    }
    return 0;
}


int CommandParser::setInputStream(std::string scriptFilePath)
{
    std::ifstream scriptFile(scriptFilePath.c_str());
    if(scriptFile)
	{
        DIAG_INFO("File to parse is: " << scriptFilePath);
        std::string cmdHelper;
        int lineNr = 0;
        std::vector<std::string> vecOfCmds;
        while (std::getline(scriptFile, cmdHelper))
		{
            if(cmdHelper.size() > 0)
                vecOfCmds.push_back(cmdHelper);
        }
        scriptFile.close();
        for(auto cmdHelper : vecOfCmds)
		{
            lineNr = lineNr + 1;
            DIAG_INFO("Command Nr."<<lineNr<<" to parse is: " << cmdHelper);
            while(!shouldCancel) {
                parse(cmdHelper);
            }
        }
        DIAG_INFO("In total "<<lineNr<<" commands are parsed");
    } 
	else
        DIAG_ERROR("Cannot open the script file due to invalid file path input");
	return 0;
}


