///////////////////////////////////////////////////////////
//  ModeCommand.cpp
//  Implementation of the Class ModeCommand
//  Created on:      28-Mai-2019 17:27:24
//  Original author: student
///////////////////////////////////////////////////////////

#include <ModeCommand.h>
#include <ConcreteDriveController.h>
#include <DrivingMode.h>

ModeCommand::ModeCommand(){

}



ModeCommand::~ModeCommand(){

}



/*set Driving Mode: 1.Automatic 2.Manuell */
int ModeCommand::execute(int modeNr){
	int m_num = modeNr;
	myDriveController = ConcreteDriveController::getInstance();
	DrivingMode driveMode;
	if (m_num == 1)
	{
		driveMode = DRIVE_AUTO;
	}
	else 
	{
		driveMode = DRIVE_MANUAL;
	}
	myDriveController->setMode(driveMode);
	return 0;
}