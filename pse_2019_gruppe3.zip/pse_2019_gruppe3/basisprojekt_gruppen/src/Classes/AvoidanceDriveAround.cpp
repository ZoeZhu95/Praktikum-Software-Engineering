///////////////////////////////////////////////////////////
//  AvoidanceDriveAround.cpp
//  Implementation of the Class AvoidanceDriveAround
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#include <AvoidanceDriveAround.h>


AvoidanceDriveAround::AvoidanceDriveAround(){

}

AvoidanceDriveAround::~AvoidanceDriveAround(){

}

DriveParameters AvoidanceDriveAround::avoid(){

	DriveParameters driveParameters;
	return driveParameters;

}