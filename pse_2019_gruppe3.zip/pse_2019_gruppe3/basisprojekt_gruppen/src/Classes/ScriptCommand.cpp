///////////////////////////////////////////////////////////
//  ScriptCommand.cpp
//  Implementation of the Class ScriptCommand
//  Created on:      28-Mai-2019 17:27:26
//  Original author: student
///////////////////////////////////////////////////////////

#include <ScriptCommand.h>


ScriptCommand::ScriptCommand(){

}



ScriptCommand::~ScriptCommand(){

}



int ScriptCommand::execute(){

	return 0;
}