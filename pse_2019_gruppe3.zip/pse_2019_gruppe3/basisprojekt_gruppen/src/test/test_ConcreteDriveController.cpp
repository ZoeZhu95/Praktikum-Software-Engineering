#include "../..//include/Classes/ConcreteDriveController.h"
#include "../../include/DriveController.hpp"
#include <gmock/gmock.h>
#include <gtest/gtest.h>

class MockDriveController : public DriveController {
	public:
		...
		MOCK_METHOD0(step, void());
		MOCK_METHOD0(getTestMode, bool());
		MOCK_METHOD1(setTestMode, void(bool enable));
		MOCK_METHOD2(updateDirectMotor, bool(int speedLeft, int speedRight));
		MOCK_METHOD2(updateDirect, bool(int speed, int steering));
		MOCK_METHOD2(updateController, bool(int speed, int steering));
};

using ::testing::AtLeast;

TEST(ConcreteDriveControllerTest, UpdatOrderTest) {
	MockDriveController mockDriveController;
	InSequence dummy;
	EXPECT_CALL(mockDriveController, updateDirect(0, 0).Times(1));
	EXPECT_CALL(mockDriveController, updateDirect(1, 1).Times(1));
	EXPECT_CALL(mockDriveController, updateDirect(2, 2).Times(1));
	EXPECT_CALL(mockDriveController, updateDirect(3, 3).Times(1));
	EXPECT_CALL(mockDriveController, updateDirect(0, 0).Times(1));

	ConcreteDriveController concreteDriveController;
	concreteDriveController.step();
	concreteDriveController.update(1, 1, 1);
	concreteDriveController.step();
	concreteDriveController.update(2, 2, 2);
	concreteDriveController.update(2, 1, 1);
	concreteDriveController.step();

}