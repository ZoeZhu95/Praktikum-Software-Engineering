///////////////////////////////////////////////////////////
//  ObstacleAvoidance.h
//  Implementation of the Class ObstacleAvoidance
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#include <ConcreteDriveController.h>
#include <Priority.h>
#include <EmergencyDetector.h>
#include <DriveParameters.h>

///detect a static obstacle in the ambience and use a strategy to avoide it
/**@details
* !!This class is still in progress.
* This class is aimed to use an algorithm to detect an obstacle around TivSeg.
* With this algorithm we firstly get depths of some sampled points in the image
* and then subtract the depth of each two neighbour. If some differences of them 
* are relativ unusal bigger, then there could be an obstacle at this point.
* To ensure those are not noises, we still need to check more points.
* So we check the differences between this point and its neighbours, also neighbours' 
* neighbours. If there are still any other unsual differences, then there is surely 
* an obstacle in this area.
*/
class ObstacleAvoidance : public Observer {

public:
	///detect obstacle and give an appropriate steering and speed to TivSeg
	/*
	* @return DriveParameters give an appropriate steering and speed to TivSeg
	*/
	DriveParameters detectObstacle();

	///update the current data
	void update();

private:
	ConcreteSensorManager* sensorManager_;
	Priority priority_;
};

#pragma once
