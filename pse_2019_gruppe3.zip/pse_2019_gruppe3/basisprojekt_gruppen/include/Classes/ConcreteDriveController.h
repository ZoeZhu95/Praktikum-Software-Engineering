///////////////////////////////////////////////////////////
//  ConcreteDriveController.h
//  Implementation of the Interface DriveController
//  Created on:      28-Mai-2019 17:27:23
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_CF8B9FF8_0057_444d_832E_3A38B96CA18D__INCLUDED_)
#define EA_CF8B9FF8_0057_444d_832E_3A38B96CA18D__INCLUDED_

#include <queue>

#include <DrivingMode.h>
#include <Priority.h>
#include <DriveController.hpp>
#include <DriveParameters.h>

/// ConcreteDriveController is a Decorator for the provided Drivecontroller interface, it provides more Functionality than the original. Class is a Singleton.
/** @details
* ConcreteDriveController holds a reference to the Drivecontroller and uses it to call the update Methods of the Drivecontroller.
* ConcreteDriveController automatically selects the correct update Function to call according to the set Test Mode.
* Calling the update function may reset the current instruction if the priority of the new instruction is of equal or higher Priority.
* Updates are scheduled according to the priority of the update.
* The last instruction is executed by calling the step function.
* To flush all instructions and sets the active instruction to "stop".
*/
class ConcreteDriveController : public DriveController{

public:
	///Method for getting the currently set DrivingMode.
	/* @return Returns the current DrivingMode.
	*/
	DrivingMode getMode();
	/// getInstance for getting an instance of the Class
	/* @return Returns a Pointer to the concreteDriveController.
	*/
	static ConcreteDriveController* getInstance();
	/// Checks if current DrivingMode is a Test Mode.
	/* @return Returns true if the current DrivingMode is a Test mode, false if not.
	*/
	bool getTestMode();
	/// Sets the Enum for the DrivingMode.
	/** @details
	* Accepted values are: TEST_AUTO, TEST_MANUAL, AUTO, MANUAL
	* @param  mode The DrivingMode that the ConcreteDriveController will be set to.
	* @return Returns the value of the enum that the ConcreteDriveController is set to.
	*/
	int setMode(int mode);
	/// Enables/Disables TestMode for the current DrivingMode.
	/* @param enable set to true if you want to enable Testing mode and set to false if you want to disable Testing mode.
	*/
	void setTestMode(bool enable);
	/// Calls the step Function of the DriveController. Also executes the currently active Instruction.
	void step();
	/// Updates the active Instruction. should be followed by a step() call to execute the updated instruction.
	/* @details
	* Updating the ConcreteDriveController with lower Priority than the active Instruction produces no change.
	* Updating with higher or equal Priority updates the active instruction.
	* If the current Mode is not AUTO or TEST_AUTO the Input of Tracking priority are ignored.
	* @param speed The speed for the next motor update. Expects a value [0, 100].
	* @param steering The steering for the next motor update. Expects a value [-100, 100].
	* @param priority Priority value for the update, update requests with higher priority take precedence.
	* @return Returns true if successful.
	*/
	bool update(int speed, int steering, Priority priority);
	/// Method for directly controlling the Wheel speeds for integration Tests.
	/* @param speedLeft the rotational speed of the left wheel. Expects value [-100, 100].
	* @param speedRight the rotational speed of the right wheel. Expects value [-100, 100].
	* @return Returns true if successful. 
	*/
	bool updateDirectMotor(int speedLeft, int speedRight);
	/// Flushes all instructions of lower priority than the inputted priority.
	/*@details
	* An equal or higher priority flush than the active Instruction sets the active instruction to "stop".
	* The "stop" Instruction has 0 speed and 0 steering.
	* @param priority The priority up to which update requests are to be flushed. Should not exceed the own priority rating.
	* @return Returns 0 if successful.
	*/
	int flush(Priority priority);
	/// Function for getting the currently set Speed.
	/* @return Returns the speed value of the active Instruction as an int value. If no speed has been set returns zero.
	*/
	int getSpeed();
	/// Function for Inserting a DriveController
	/*@details Manualy sets the DriveController being used. Meant for testing purposes.
	* @param driveController The driveController whose functionality you wish to be injected into the ConcreteDriveController.
	*/
	void setDriveController(DriveController* driveController);

private:
	ConcreteDriveController();
	virtual ~ConcreteDriveController();
	
	static DriveController *driveController_;
	static ConcreteDriveController *instance_;
	DrivingMode currentMode_;
	DriveParameters currentInstruction_;
	Priority currentPriority_;
	std::queue<DriveParameters> trackingQueue_;
	std::queue<DriveParameters> manualQueue_;
	std::queue<DriveParameters> avoidanceQueue_;
	std::queue<DriveParameters> emergencyQueue_;

	/// Calls the updateController Method of the used DriveController
	/* @param speed The speed to be set. Must be [0, 100].
	* @param steering The steering to be set. Must be [-100, 100].
	* @return Returns true if successful.
	*/
	bool updateController(int speed, int steering);
	/// Calls the updateDirect Method of th current DriveController
	/* @param speed The speed to be set. Must be [0, 100].
	* @param steering The steering to be set. Must be [-100, 100].
	* @return Returns true if successful.
	*/
	bool updateDirect(int speed, int steering);
	/// Sets the active Instruction of the ConcreteDriveController
	void setInstruction();

};
#endif // !defined(EA_CF8B9FF8_0057_444d_832E_3A38B96CA18D__INCLUDED_)
