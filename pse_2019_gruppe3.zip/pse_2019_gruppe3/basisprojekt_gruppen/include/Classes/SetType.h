///////////////////////////////////////////////////////////
//  SetType.h
//  Implementation of the Enumeration SetType
//  Created on:      28-Mai-2019 17:27:27
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_A7EDF5BC_3FC3_40d7_B675_56DDC9C2873B__INCLUDED_)
#define EA_A7EDF5BC_3FC3_40d7_B675_56DDC9C2873B__INCLUDED_
/// This class enumerate all types for setCommand
enum SetType
{
	LOGGING,
	RUN_TIME,
	DISTANCE_TO_MARKER
};
#endif // !defined(EA_A7EDF5BC_3FC3_40d7_B675_56DDC9C2873B__INCLUDED_)
