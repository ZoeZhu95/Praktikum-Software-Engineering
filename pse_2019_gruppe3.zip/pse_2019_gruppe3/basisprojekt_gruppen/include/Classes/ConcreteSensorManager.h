///////////////////////////////////////////////////////////
//  SensorManager.h
//  Implementation of the Interface SensorManager
//  Created on:      28-Mai-2019 17:27:26
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_DF0C8399_C969_4ad7_BECE_6BDA4B197DAE__INCLUDED_)
#define EA_DF0C8399_C969_4ad7_BECE_6BDA4B197DAE__INCLUDED_

#include <Observer.h>
#include <SensorManager.hpp>

/// The ConcreteSensorManger is a decorator for the provided Sensormanager. It provides additional methods. It is also a Singleton
/* @details The ConcreteSensorManager realizes the observer pattern. 
*/
class ConcreteSensorManager : public SensorManager{

public:
	///Function for querying the detected Markers.
	/* @returns Returns a List of all the detected Markers.
	*/
	std::vector<MarkerInfo>& get_marker_list();
	/// Function for queriying the depth at a pixel.
	/* @param x The index of the Pixel to be queried in the x direction of the Image. (width)
	* @param y The index of the Pixel to be queried in the x direction of the Image. (height)
	* @return Returns the depth value for a pixel specified by its x and y coordinates.
	*/
	double getDepth(int x, int y);
	/// Get an Average of the current processing FPS.
	/* @return Returns an average of the underlying SensorMangers current processing FPS.
	*/
	float getFps();
	/// Gets an Insatnce of the ConcreteSensormanager.
	/* @return Returns the ConcreteSensormanager Singleton.
	*/
	static ConcreteSensorManager getInstance();
	/// Gets the Sensors height.
	/* @return Get the height of the sensor Data.
	*/
	int getSensorHeight();
	/// Gets the SEnsors width.
	/* @return Get the width of the sensor Data.
	*/
	int getSensorWidth();
	/// Manually set the SensorManger to be used by ConcreteSensorManager to realize it's functionality.
	/* @param sensorManager The sensorManager whose functionality should be injected into ConcreteSensorManager.
	*/
	void setSensorManager(SensorManager sensorManager);
	/// Notifies all observers registered with this ConcreteSensorManger.
	void notifyObservers();
	/// Registers the passed observer with this ConcreteSensorManager.
	/* @details A Registered Observer needs to implement the update() method. All registered will be notified when there is new data.
	* @param observer The observer to be registered for notification.
	* @return Returns 0 if successful.
	*/
	int registerObserver(Observer* observer);
	/// Prompts the underlying SensorManager to get new Data.
	/* @return Returns true if successfull.
	*/
	bool runOnce();
	/// Unregeisters the passed observer from the ConcreteSensorManager. Unregistered Observers do not receive notifications.
	/* @param observer unregisters the observer from the notification service.
	* @return Returns true if successful.
	*/
	bool unregisterObserver(Observer* observer);
	

private:
	ConcreteSensorManager();
	virtual ~ConcreteSensorManager();

	static ConcreteSensorManager *instance_;
	static SensorManager *sensorManager_;
	std::vector<Observer*> observerCollection_;

};
#endif // !defined(EA_DF0C8399_C969_4ad7_BECE_6BDA4B197DAE__INCLUDED_)
