///////////////////////////////////////////////////////////
//  DriveCommand.h
//  Implementation of the Class DriveCommand
//  Created on:      28-Mai-2019 17:27:23
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_6BF88126_6CE2_4999_853E_8125F5B451F3__INCLUDED_)
#define EA_6BF88126_6CE2_4999_853E_8125F5B451F3__INCLUDED_

#include <ConcreteDriveController.h>
#include <Command.h>
/// This class is a concrete command to change the driving condition w.r.t time, speed and steering 
class DriveCommand : public Command
{

public:
	DriveCommand();
	virtual ~DriveCommand();
	ConcreteDriveController *myDriveController;
/// This method executes drive command with 3 parameters
///@param argTime driving time,pre-defined max time 60 sec 
///@param argSpeed driving speed,range[-100,100]
///@param argSteering,range[-100,100], -100 towards left, 100 towards right
///@return return 0 means a successful execution
	int execute(unsigned int argTime, int argSpeed, int argSteering);
/// This method executes drive command with 2 parameters, steering is default value 0 grad
///@param argTime driving time, pre-defined max time 60 sec 
///@param argSpeed driving speed,range[-100,100]
///@return return 0 means a successful execution
	int execute(unsigned int argTime, int argSpeed);

};
#endif // !defined(EA_6BF88126_6CE2_4999_853E_8125F5B451F3__INCLUDED_)
