///////////////////////////////////////////////////////////
//  Observer.h
//  Implementation of the Class Observer
//  Created on:      28-Mai-2019 17:27:24
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_448B2076_74A0_4c81_99F1_6F84DD80328E__INCLUDED_)
#define EA_448B2076_74A0_4c81_99F1_6F84DD80328E__INCLUDED_

///observe the changes of SensorManager and update the current data
class Observer
{

public:
	///constructor of class Observer
	Observer();

	///deconstructor of class Observer
	virtual ~Observer();

	///update current data
	void update();

};
#endif // !defined(EA_448B2076_74A0_4c81_99F1_6F84DD80328E__INCLUDED_)
