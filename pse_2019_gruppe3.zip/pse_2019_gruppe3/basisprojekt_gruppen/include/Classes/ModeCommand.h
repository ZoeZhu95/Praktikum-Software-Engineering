///////////////////////////////////////////////////////////
//  ModeCommand.h
//  Implementation of the Class ModeCommand
//  Created on:      28-Mai-2019 17:27:24
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_61212FDC_41D0_4f2d_AEB7_C96EAE2CA422__INCLUDED_)
#define EA_61212FDC_41D0_4f2d_AEB7_C96EAE2CA422__INCLUDED_

#include <ConcreteDriveController.h>
#include <Command.h>
///This class is a concrete command class to switch the driving mode
class ModeCommand : public Command
{

public:
	ModeCommand();
	virtual ~ModeCommand();
	ConcreteDriveController *myDriveController;
/// This method sets up driving mode
/// @param modeNr: 1.automatic driving 2.manuell driving
/// @return return 0 means a successful execution
	int execute(int modeNr);

};
#endif // !defined(EA_61212FDC_41D0_4f2d_AEB7_C96EAE2CA422__INCLUDED_)
