
///DriveParameters: speed and steering
class DriveParameters
{
public:
	DriveParameters();
	virtual ~DriveParameters();

	///speed Percentage of max speed; range is -100 to 100.
	int speed;
	///steering Percentage of steering; range is -100 to 100.
	int steering;
};