///////////////////////////////////////////////////////////
//  MarkerDetector.h
//  Implementation of the Class MarkerDetector
//  Created on:      28-Mai-2019 17:27:24
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_A9BC9952_063B_45ea_851B_D6EAA5F85B6B__INCLUDED_)
#define EA_A9BC9952_063B_45ea_851B_D6EAA5F85B6B__INCLUDED_

#include <vector>

#include <Point.h>
#include <Observer.h>
#include <MarkerInfo.hpp>
#include <TrackingHandler.h>
#include <ConcreteSensorManager.h>

///markerDetector detect a valid followMarker and give it's coordinate
class MarkerDetector : public Observer
{

public:
	MarkerDetector();
	virtual ~MarkerDetector();

	///possible IDs of valid Markers
	const int possibleIDs[5] = { 17, 23, 36, 37, 42 };

	///set a follow ID, use this before automatic drive mode
	/*
	* @param followID is the ID to follow
	*/
	void setMarkerID(int followID);

	///update the list of detected markers.
	void update();

	///if a valid Marker is found
	/*
	* @return true on yes, false on no
	*/
	bool seesMarker_f();

	///calculate the coordinate of this marker's center
	/*
	* @return point the coordinate of this marker's center
	*/
	Point getMarkerCenter();

protected:
	Point markerCenter;
	bool seesMarker;

private:
	ConcreteSensorManager* sensorManager_;
	TrackingHandler* trackingHandler_;
	std::vector<MarkerInfo> markerlist_;
	int followID_;

};
#endif // !defined(EA_A9BC9952_063B_45ea_851B_D6EAA5F85B6B__INCLUDED_)#pragma once
