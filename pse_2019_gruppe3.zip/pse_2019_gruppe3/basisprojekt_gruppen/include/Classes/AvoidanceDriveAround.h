///////////////////////////////////////////////////////////
//  AvoidanceDriveAround.h
//  Implementation of the Class AvoidanceDriveAround
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_0F8EC21E_3BCD_4e9f_9338_A11D3AE86623__INCLUDED_)
#define EA_0F8EC21E_3BCD_4e9f_9338_A11D3AE86623__INCLUDED_

#include <AvoidanceStrategy.h>
#include <DriveParameters.h>

///Generate driving around parameters. This class is still in progress.
class AvoidanceDriveAround : public AvoidanceStrategy
{

public:
	///constructor of class AvoidanceDriveAround
	AvoidanceDriveAround();

	///deconstructor of class AvoidanceDriveAround
	virtual ~AvoidanceDriveAround();

	///generate driving around parameters
	/*
	* @return the value of steering and speed
	*/
	DriveParameters avoid();

};
#endif // !defined(EA_0F8EC21E_3BCD_4e9f_9338_A11D3AE86623__INCLUDED_)
