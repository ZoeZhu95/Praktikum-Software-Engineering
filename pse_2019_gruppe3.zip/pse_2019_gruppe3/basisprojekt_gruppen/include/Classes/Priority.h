///////////////////////////////////////////////////////////
//  Priority.h
//  Implementation of the Enumeration Priority
//  Created on:      28-Mai-2019 17:27:26
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_D8964A93_2A48_41d4_BF6B_26A08E45464F__INCLUDED_)
#define EA_D8964A93_2A48_41d4_BF6B_26A08E45464F__INCLUDED_

///Enum for Priority ordering for the ConcreteDriveController.
enum Priority{
	TRACKING,
	MANUAL,
	AVOIDANCE,
	EMERGENCY,
	DISASTER
};
#endif // !defined(EA_D8964A93_2A48_41d4_BF6B_26A08E45464F__INCLUDED_)
