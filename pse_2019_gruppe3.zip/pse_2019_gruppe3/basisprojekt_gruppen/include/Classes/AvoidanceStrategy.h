///////////////////////////////////////////////////////////
//  AvoidanceStrategy.h
//  Implementation of the Class AvoidanceStrategy
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_C2D7A2FF_DFDA_4e83_BBD4_867F27C747C5__INCLUDED_)
#define EA_C2D7A2FF_DFDA_4e83_BBD4_867F27C747C5__INCLUDED_

#include <DriveParameters.h>

///Decide an appropriate strategy to avoid obstacles
/**@details
* !!This class is still in progress.
* This class is aimed to decide whether TivSeg should stop or drive around to avoid
* the obstacles. If the obstacle is too close to TivSeg, the TivSeg should stop immediatly.
* Otherwise, it could drive around and bypass it.
*/
class AvoidanceStrategy
{

public:
	///constructor of class AvoidanceStratedy
	AvoidanceStrategy();

	///deconstructor of class AvoidanceStratedy
	virtual ~AvoidanceStrategy();

	///avoid obstacles
	/**
	* @return speed and steering parameters
	*/
	DriveParameters avoid();

};
#endif // !defined(EA_C2D7A2FF_DFDA_4e83_BBD4_867F27C747C5__INCLUDED_)
