///////////////////////////////////////////////////////////
//  CommandParser.h
//  Implementation of the Class CommandParser
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_EB76E340_3C4F_405e_B53A_F77842CF9B33__INCLUDED_)
#define EA_EB76E340_3C4F_405e_B53A_F77842CF9B33__INCLUDED_

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

#include <Diagnostic.h>
#include <Command.h>

#define max_drive_time 60
///This class parses the user command, shows the parsed result on console and logs it in log-file
class CommandParser
{

public:
	CommandParser();
	virtual ~CommandParser();
	Command *myCommand;
///parses every single command
///@param input argument cmdToExecute is the command to be parsed, string type 
///@return return 0 means successful execution
	int parseCommand(std::string cmdToExecute);
///works for script command, parses a command list in a file 
///@param expected file path 
///@return return 0 means successful execution
	int setInputStream(std::string file_path);
///if interrupt signal received, stop command execution
	static bool shouldCancel;

private:
	std::stringstream commandsInput_;

};
#endif // !defined(EA_EB76E340_3C4F_405e_B53A_F77842CF9B33__INCLUDED_)
