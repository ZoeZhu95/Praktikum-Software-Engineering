///////////////////////////////////////////////////////////
//  Command.h
//  Implementation of the Class Command
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_F629AB43_EA79_4407_9196_D153FE6024AF__INCLUDED_)
#define EA_F629AB43_EA79_4407_9196_D153FE6024AF__INCLUDED_

#include <Diagnostic.h>

/// This class is the father of all concrete command
class Command
{

public:
	Command();
	virtual ~Command();
	/// this method execute a command
	/// @return return 0 means a successful execution
	virtual int execute();

private:
	Diagnostic *myDiagnostic_;

};
#endif // !defined(EA_F629AB43_EA79_4407_9196_D153FE6024AF__INCLUDED_)
