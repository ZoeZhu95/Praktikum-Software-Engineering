///////////////////////////////////////////////////////////
//  SearchCommand.h
//  Implementation of the Class SearchCommand
//  Created on:      28-Mai-2019 17:27:26
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_DD017CCE_D73F_451f_8AB6_487A858108C2__INCLUDED_)
#define EA_DD017CCE_D73F_451f_8AB6_487A858108C2__INCLUDED_

#include <TrackingHandler.h>
#include <Command.h>
///This class is a concrete command for notifying the tracking handler to search a mark
class SearchCommand : public Command
{

public:
	SearchCommand();
	virtual ~SearchCommand();
	TrackingHandler *m_TrackingHandler;
	/// This method execute search command
	///@return return 0 means a successful execution
	int execute();

private:
	int search();

};
#endif // !defined(EA_DD017CCE_D73F_451f_8AB6_487A858108C2__INCLUDED_)
