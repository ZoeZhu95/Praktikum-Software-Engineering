///////////////////////////////////////////////////////////
//  Point.h
//  Implementation of the Class Point
//  Created on:      28-Mai-2019 17:27:25
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_1F7C4447_74BF_4e12_A75B_D2DFAE609EEF__INCLUDED_)
#define EA_1F7C4447_74BF_4e12_A75B_D2DFAE609EEF__INCLUDED_

///Information of a point
class Point
{
public:
	Point();
	virtual ~Point();

	///x coordinate
	int xValue;

	///y coordinate
	int yValue;

	///depth of point(x, y)
	double depth;

};
#endif // !defined(EA_1F7C4447_74BF_4e12_A75B_D2DFAE609EEF__INCLUDED_)
