///////////////////////////////////////////////////////////
//  MainController.h
//  Implementation of the Class MainController
//  Created on:      28-Mai-2019 17:27:24
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_1E761E51_7BA0_4706_AE9A_98817616DB73__INCLUDED_)
#define EA_1E761E51_7BA0_4706_AE9A_98817616DB73__INCLUDED_

#include <thread>
#include <string>

#include <ConcreteSensorManager.h>
#include <ConcreteDriveController.h>
#include <CommandParser.h>

/// Zentrales Steuerelement des Projekts.
/*@details This is where blocking functionality for Cammands is focused. 
* This class handles interruption of execution when the time between inputs exceeds the time limit.
* This class contains the Value for the distance at which the marker is to be followed.
*/
class MainController{

public:
	MainController();
	virtual ~MainController();
	ConcreteSensorManager *concreteSensorManager;
	CommandParser *commandParser;

	/// Set Frequent calls to the sensorManagers runOnce() and the DriveControllers step() function.
	/* @details If active=true Frequent calls are being made.
	* To turn these off set active = false.
	* @param active if this is set to true, calls are made. If it is set to false no calls are made.
	*/
	void callFrequently(bool active);
	/// Sets the control interval.
	/* @details Expects an integer Input in miliseconds.
	* @param input The maximum time interval between two calls in miliseconds.
	* @return Returns zero if successful.
	*/
	static int setControlInterval(int input);
	/// Sets the follow DIstance
	/* @details Expects a double value for the distance value at which the segway should follow the marker.
	* @param distance the Distance the segway should keep to the marker.
	* @return Returns zero if successfull in setting the followDistance.
	*/
	static int setFollowDistance(double distance);
	/// Receives User input.
	/* @details The user input is parsed using the BefehlsParser
	* @return the return value of the failed parse() command.
	*/
	int takeUserInput();
	/// Get the follow Distance.
	/* @return The distance at which the marker should be followed as a double.
	*/
	double getFollowDistance();
	/// function for updating the last command timestamp. Should be called every time an instruction has been inputted.
	void updateCommandTimer();
	

private:
	/// function for checking whether the acceptable interval between inputs has been observed.
	/* @details If the Interval has not been observed all Instructions of the driveController will be flushed and the callFrequently function will be suspended.
	*/
	void checkStopTime();

	std::thread asyncCall_;
	/// the function being executed in callFrequently
	void asyncCallFrequently();
	bool callFrequentlyActive_;
	double followDistance_;
	bool isExecutingCommand_;
	int lastCommandTimestamp_;
	int lastCommandInterval_;
	ConcreteDriveController *concreteDriveController_;
	const int RUN_ONCE_INTERVAL_ = 30;
	const int STEP_INTERVAL_ = 10;

};
#endif // !defined(EA_1E761E51_7BA0_4706_AE9A_98817616DB73__INCLUDED_)
