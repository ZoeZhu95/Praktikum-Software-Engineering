///////////////////////////////////////////////////////////
//  ScriptCommand.h
//  Implementation of the Class ScriptCommand
//  Created on:      28-Mai-2019 17:27:26
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_000565FC_233C_4bd1_9FE9_4C610F30258D__INCLUDED_)
#define EA_000565FC_233C_4bd1_9FE9_4C610F30258D__INCLUDED_

#include <CommandParser.h>
#include <Command.h>
/// This class is designed to execute a list of commands, whereas replaced by setInputString() in class CommandParser 
class ScriptCommand : public Command
{

public:
	ScriptCommand();
	virtual ~ScriptCommand();
	CommandParser *m_CommandParser;

	int execute();

};
#endif // !defined(EA_000565FC_233C_4bd1_9FE9_4C610F30258D__INCLUDED_)
