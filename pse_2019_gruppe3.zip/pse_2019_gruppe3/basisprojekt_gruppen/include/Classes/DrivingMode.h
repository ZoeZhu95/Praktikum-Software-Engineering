///////////////////////////////////////////////////////////
//  DrivingMode.h
//  Implementation of the Enumeration DrivingMode
//  Created on:      28-Mai-2019 17:27:24
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_A3CD866C_EB2E_48fe_9F07_FE69041AD647__INCLUDED_)
#define EA_A3CD866C_EB2E_48fe_9F07_FE69041AD647__INCLUDED_

///Enum specifying the operation mode of ConcreteDriveController.
/* @details A user can pick two operation modes: Manual mode and Automatic mode.
* For Testing purposes the DriveController provides different methods to forward commands to the motor.
* This Enum can represent any combination of these modes and enables the ConcreteDriveController to execute only the relevant commands with the correct method.
*/
enum DrivingMode {
	DRIVE_TEST_MANUAL,
	DRIVE_TEST_AUTO,
	DRIVE_MANUAL,
	DRIVE_AUTO
};
#endif // !defined(EA_A3CD866C_EB2E_48fe_9F07_FE69041AD647__INCLUDED_)
