///////////////////////////////////////////////////////////
//  ObstacleHandler.h
//  Implementation of the Class ObstacleHandler
//  Created on:      28-Mai-2019 17:27:25
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_B7C8BF11_FC5A_4802_ACB9_A07BB0321FB4__INCLUDED_)
#define EA_B7C8BF11_FC5A_4802_ACB9_A07BB0321FB4__INCLUDED_

/// The ObstacleHandler is get the path by avoiding the obstacle
class ObstacleHandler
{

public:
	ObstacleHandler();
	virtual ~ObstacleHandler();
	/// decide the strategy to get the path to follow by avoiding obstacle
	int invertEvasionPath();
	/// get the distance of sample points that was chosen on the obstacle-avoiding path
	int sampleDistancePoints();

};
#endif // !defined(EA_B7C8BF11_FC5A_4802_ACB9_A07BB0321FB4__INCLUDED_)
