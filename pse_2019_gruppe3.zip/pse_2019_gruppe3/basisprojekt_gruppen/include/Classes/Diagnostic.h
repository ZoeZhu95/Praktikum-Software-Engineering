///////////////////////////////////////////////////////////
//  Diagnostic.h
//  Implementation of the Class Diagnostic
//  Created on:      28-Mai-2019 17:27:23
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_622ED93E_FC87_48e4_BF81_30989DA3E26A__INCLUDED_)
#define EA_622ED93E_FC87_48e4_BF81_30989DA3E26A__INCLUDED_

#include <Diagnostics.hpp>

// Convenience macros
#undef DIAG_VERBOSE
#undef DIAG_DEBUG
#undef DIAG_INFO
#undef DIAG_WARNING
#undef DIAG_ERROR
/** Set the maximal level of Diagnostics. 
 *  Possible Diagnostics levels are:
 *  DIAG_VERBOSE
 *  DIAG_DEBUG
 *  DIAG_INFO
 *  DIAG_WARNING
 *  DIAG_ERROR
 */
#define DIAG_MAX_LEVEL(lvl) Diagnostic::setMaxLevel(lvl)
#define DIAG_VERBOSE(msg, ...) Diagnostic::log(DIAG_VERBOSE, __FILE__, __LINE__, msg, ##__VA_ARGS__) //!< Log message with "verbose" level 
#define DIAG_DEBUG(msg, ...) Diagnostic::log(DIAG_DEBUG, __FILE__, __LINE__, msg, ##__VA_ARGS__) //!< Log message with "debug" level 
#define DIAG_INFO(msg, ...) Diagnostic::log(DIAG_INFO,  __FILE__, __LINE__, msg, ##__VA_ARGS__) //!< Log message with "info" level 
#define DIAG_WARNING(msg, ...) Diagnostic::log(DIAG_WARNING, __FILE__, __LINE__, msg, ##__VA_ARGS__) //!< Log message with "warning" level 
#define DIAG_ERROR(msg, ...) Diagnostic::log(DIAG_ERROR, __FILE__, __LINE__, msg, ##__VA_ARGS__) //!< Log message with "error" level 

// Debug output file
#define DIAG_OUTPUT "Debug.txt"
#define OUTPUT_FLUSH

///This class is for logging data while running
class Diagnostic
{

public:
	/// This method logs a message and shows it in console
	/// @param Level shows priority level of the current log-message
	/// @param File is the file path of the log data
	/// @param Line is the line number in the file of the log data
	/// @param msg is the captured message
	/// @param ... is the supplementary information to log with msg, arbitrary type
	static void log(DiagnosticLevel Level, const char* File, int Line, const char* const msg);
	/// This method sets the max diagnostic level
	/// all messages below this level will be ignored
	/// @param Level the new max level
	static void setMaxLevel(DiagnosticLevel Level);
	/// Static variable for the diagnosticsLevel
	static DiagnosticLevel diagnosticsLevel; 

private:
	~Diagnostic();
	Diagnostic();
};
#endif // !defined(EA_622ED93E_FC87_48e4_BF81_30989DA3E26A__INCLUDED_)
