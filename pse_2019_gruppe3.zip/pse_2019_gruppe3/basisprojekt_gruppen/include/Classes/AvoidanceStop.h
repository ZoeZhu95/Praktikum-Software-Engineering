///////////////////////////////////////////////////////////
//  AvoidanceStop.h
//  Implementation of the Class AvoidanceStop
//  Created on:      28-Mai-2019 17:27:22
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_119DBA91_BA27_4f24_A066_CFDAFE35981E__INCLUDED_)
#define EA_119DBA91_BA27_4f24_A066_CFDAFE35981E__INCLUDED_

#include <AvoidanceStrategy.h>
#include <DriveParameters.h>

///Generate stop parameters of TivSeg. This class is still in progress.
class AvoidanceStop : public AvoidanceStrategy
{
public:
	///constructor of class AvoidanceStop
	AvoidanceStop();

	///deconstructor of class AvoidanceStop
	virtual ~AvoidanceStop();

	///generate stop parameters of TivSeg
	DriveParameters avoid();

};
#endif // !defined(EA_119DBA91_BA27_4f24_A066_CFDAFE35981E__INCLUDED_)
