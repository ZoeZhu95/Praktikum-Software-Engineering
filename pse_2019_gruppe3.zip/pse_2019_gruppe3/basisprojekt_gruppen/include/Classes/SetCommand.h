///////////////////////////////////////////////////////////
//  SetCommand.h
//  Implementation of the Class SetCommand
//  Created on:      28-Mai-2019 17:27:27
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_9AE9C39D_B086_4625_92D6_88410C1845BB__INCLUDED_)
#define EA_9AE9C39D_B086_4625_92D6_88410C1845BB__INCLUDED_

#include <MainController.h>
#include <Diagnostic.h>
#include <Command.h>
#include <SetType.h>
///This class is a concrete command to do the prelimary settings 
class SetCommand : public Command
{

public:
	SetCommand();
	virtual ~SetCommand();
	HauptController *m_HauptController;
	Diagnostic *m_Diagnostic;
///This method executes set command
///@param art type of set command: -l, -t, -d, represent for set log level, set maximal time interval, set distance to trace mark
///@param value argument of each set command
///@return return 0 means a successful execution
	int execute(SetType art, unsigned int value);

};
#endif // !defined(EA_9AE9C39D_B086_4625_92D6_88410C1845BB__INCLUDED_)
