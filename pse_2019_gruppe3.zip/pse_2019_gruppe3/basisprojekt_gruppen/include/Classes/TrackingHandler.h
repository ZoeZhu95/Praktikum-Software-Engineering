///////////////////////////////////////////////////////////
//  TrackingHandler.h
//  Implementation of the Class TrackingHandler
//  Created on:      28-Mai-2019 17:27:27
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_0ADA0110_A4A9_498f_AE76_5F30886BDF28__INCLUDED_)
#define EA_0ADA0110_A4A9_498f_AE76_5F30886BDF28__INCLUDED_

#include <markerDetector.h>
#include <ConcreteSensorManager.h>
#include <Priority.h>
#include <Diagnostic.h>
#include <ConcreteDriveController.h>
#include <MainController.h>
#include <Point.h>


/// The TrackingHandler is to search and provide a new dirve Paramter
/**@details
 * It connects the Infofluss from markerDetector to ConcreteDriveCOntroller
 * It will rotate and search wenn the image is updated
 * After getting a marker, call decideDriveVector to update the speed, steering and priotity
 * Drive Vector will be decided according to the postion of marker
 */
class TrackingHandler
{

public:

	/// search while image is updated 
	/**
	 * in low speed and in order not to pass the marker 
	 * if the image is updated while running
	 * @return returns true if successfully find a marker, false if not.
	 */
	bool searchMarker();
	/// calculate the drive vector and update the drive parameters
	/**
	 * set the new speed, steering and priority, so that the drive vector be decided.
	 * call update to give information to ConcreteDriveController
	 * @return returns 0 if successful.
	 */
	static int decideDriveVector();

private:
	
	TrackingHandler();
	virtual ~TrackingHandler();

	int lastSpeed_;
	int speed_;
	int steering_;
	ConcreteDriveController* myDriveController_;
	ConcreteSensorManager* mySensorManager_;
	MainController myMainController_;
	MarkerDetector markerDetector_;
	Point markerCenter_;
	
	

};
#endif // !defined(EA_0ADA0110_A4A9_498f_AE76_5F30886BDF28__INCLUDED_)
