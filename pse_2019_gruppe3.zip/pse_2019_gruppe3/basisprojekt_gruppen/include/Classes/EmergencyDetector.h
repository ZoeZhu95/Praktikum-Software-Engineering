///////////////////////////////////////////////////////////
//  EmergencyDetector.h
//  Implementation of the Class EmergencyDetector
//  Created on:      28-Mai-2019 17:27:24
//  Original author: student
///////////////////////////////////////////////////////////

#if !defined(EA_40306DBD_6983_4c4a_B48C_FB7BD9C79C60__INCLUDED_)
#define EA_40306DBD_6983_4c4a_B48C_FB7BD9C79C60__INCLUDED_

#include <Priority.h>
#include <Observer.h>
#include <ConcreteSensorManager.h>
#include <DriveParameters.h>

///Detect emergency situation and set drive steering and speed to zero
/**@details
*  This class is based on a ideal situation
*  Camera is always parallel to the ground
*/
class EmergencyDetector : public Observer
{
public:

	///set a dangerous depth which is the distance from TivSeg to objects around it
	/**
	* @param DangerDepth the dangerous depth to be set
	*/
	void setDangerDepth(int dangerDepth);

	///if emergency is detected, stop the TivSeg
	/**
	* @return DriveParameters is a parameter of steering and speed
	*/
	DriveParameters detectEmergency();

	///update the current data
	void update();

private:
	int dangerDepth_;
	Priority priority_;
	ConcreteSensorManager* sensorManager_;
};
#endif // !defined(EA_40306DBD_6983_4c4a_B48C_FB7BD9C79C60__INCLUDED_)
#pragma once
