﻿// CMakeProject1.cpp: Definiert den Einstiegspunkt für die Anwendung.
//

#include "CMakeProject1.h"

using namespace std;

int main()
{
	cout << "Hello CMake." << endl;
	return 0;
}
