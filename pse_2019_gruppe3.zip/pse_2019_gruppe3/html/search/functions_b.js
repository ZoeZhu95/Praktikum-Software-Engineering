var searchData=
[
  ['registerobserver',['registerObserver',['../class_concrete_sensor_manager.html#ac41ebbc8522f4acb22394ad7758a4f39',1,'ConcreteSensorManager']]],
  ['runonce',['runOnce',['../class_concrete_sensor_manager.html#af9b496bf94241722e1c367fa9670b0e0',1,'ConcreteSensorManager']]]
];
