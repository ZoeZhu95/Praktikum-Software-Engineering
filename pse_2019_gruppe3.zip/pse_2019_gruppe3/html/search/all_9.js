var searchData=
[
  ['notifyobservers',['notifyObservers',['../class_concrete_sensor_manager.html#ae98542d7e54408dddb8095d184aa2b87',1,'ConcreteSensorManager']]]
];
