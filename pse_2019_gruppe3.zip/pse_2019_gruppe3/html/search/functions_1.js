var searchData=
[
  ['callfrequently',['callFrequently',['../class_main_controller.html#a7b157e7113146fde37c00731873dc24b',1,'MainController']]]
];
